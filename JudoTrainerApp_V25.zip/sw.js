
self.addEventListener('install',e=>{
 e.waitUntil(
  caches.open('trainer').then(cache=>{
   return cache.addAll(['index.html'])
  })
 )
})
